from addTask import add


if __name__ == '__main__':
    add.delay(5, 5)
    
