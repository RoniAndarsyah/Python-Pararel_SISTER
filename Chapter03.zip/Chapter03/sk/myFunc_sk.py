def simple_looping(i):
    print ('Total looping sebanyak : %s' %i)
    for j in range (0,i):
        print('Looping ke : %s' %j)
    return

simple_looping(9)